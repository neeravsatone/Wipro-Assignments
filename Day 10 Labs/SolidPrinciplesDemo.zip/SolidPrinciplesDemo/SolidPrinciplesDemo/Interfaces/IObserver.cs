﻿namespace SolidPrinciplesDemo.Interfaces
{
    public interface IObserver
    {
        void Update(string data);
    }
}
