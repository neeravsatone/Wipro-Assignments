﻿namespace SolidPrinciplesDemo.Interfaces
{
    public interface IDocument
    {
        void Open();
    }
}
