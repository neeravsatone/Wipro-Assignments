﻿namespace SolidPrinciplesDemo.Interfaces
{
    public interface ISavableReport
    {
        void Save();
    }
}
