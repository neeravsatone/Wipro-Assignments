﻿using SolidPrinciplesDemo.Models;

namespace SolidPrinciplesDemo.Interfaces
{
    public interface IReportService
    {
        void ProcessReport(Report report);
    }
}
