﻿namespace SolidPrinciplesDemo.Interfaces
{
    public interface IReadableReport
    {
        string Read();
    }
}
