﻿namespace SolidPrinciplesDemo.Models
{
    public class Report
    {
        public string Content { get; set; }
    }
}
