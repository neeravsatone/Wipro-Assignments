﻿namespace SolidPrinciplesDemo.Models
{
    public class SalesReport : BaseReport
    {
        public override string GetContent()
        {
            return "Sales Report Content";
        }
    }
}
