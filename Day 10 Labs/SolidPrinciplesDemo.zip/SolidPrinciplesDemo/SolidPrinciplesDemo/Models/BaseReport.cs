﻿namespace SolidPrinciplesDemo.Models
{
    public abstract class BaseReport
    {
        public abstract string GetContent();
    }
}
