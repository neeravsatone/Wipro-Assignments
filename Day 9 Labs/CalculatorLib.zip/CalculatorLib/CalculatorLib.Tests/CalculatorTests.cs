﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using CalculatorLib;
using System;

namespace CalculatorLib.Tests
{
    [TestClass]
    public class CalculatorTests
    {
        private Calculator calculator;

        [TestInitialize]
        public void Setup()
        {
            calculator = new Calculator();
        }

        [TestMethod]
        public void Add_ReturnsCorrectSum()
        {
            Assert.AreEqual(10, calculator.Add(5, 5));
        }

        [TestMethod]
        public void Subtract_ReturnsCorrectDifference()
        {
            Assert.AreEqual(2, calculator.Subtract(5, 3));
        }

        [TestMethod]
        public void Multiply_ReturnsCorrectProduct()
        {
            Assert.AreEqual(15, calculator.Multiply(5, 3));
        }

        [TestMethod]
        public void Divide_ReturnsCorrectQuotient()
        {
            Assert.AreEqual(2, calculator.Divide(10, 5));
        }

        [TestMethod]
        [ExpectedException(typeof(DivideByZeroException))]
        public void Divide_ByZero_ThrowsException()
        {
            calculator.Divide(10, 0);
        }

        [TestMethod]
        public void Add_WithZero_ReturnsSameNumber()
        {
            Assert.AreEqual(5, calculator.Add(5, 0));
        }
    }
}
