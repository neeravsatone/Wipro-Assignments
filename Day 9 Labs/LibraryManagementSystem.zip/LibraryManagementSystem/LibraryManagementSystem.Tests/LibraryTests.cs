﻿using LibraryManagementSystem;
using Microsoft.Extensions.DependencyModel;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace LibraryManagementSystem.Tests
{
    [TestClass]
    public class LibraryTests
    {
        private Library library;

        [TestInitialize]
        public void Setup()
        {
            library = new Library();
        }

        [TestMethod]
        public void AddBook_ShouldAddBookToLibrary()
        {
            var book = new Book { Title = "C#", Author = "MS", ISBN = "111" };
            library.AddBook(book);

            Assert.AreEqual(1, library.Books.Count);
        }

        [TestMethod]
        public void RegisterBorrower_ShouldAddBorrower()
        {
            var borrower = new Borrower { Name = "John", LibraryCardNumber = "LC1" };
            library.RegisterBorrower(borrower);

            Assert.AreEqual(1, library.Borrowers.Count);
        }

        [TestMethod]
        public void BorrowBook_ShouldMarkBookAsBorrowed()
        {
            var book = new Book { Title = "C#", Author = "MS", ISBN = "111" };
            var borrower = new Borrower { Name = "John", LibraryCardNumber = "LC1" };

            library.AddBook(book);
            library.RegisterBorrower(borrower);

            library.BorrowBook("111", "LC1");

            Assert.IsTrue(book.IsBorrowed);
            Assert.AreEqual(1, borrower.BorrowedBooks.Count);
        }

        [TestMethod]
        public void ReturnBook_ShouldMakeBookAvailable()
        {
            var book = new Book { Title = "C#", Author = "MS", ISBN = "111" };
            var borrower = new Borrower { Name = "John", LibraryCardNumber = "LC1" };

            library.AddBook(book);
            library.RegisterBorrower(borrower);

            library.BorrowBook("111", "LC1");
            library.ReturnBook("111", "LC1");

            Assert.IsFalse(book.IsBorrowed);
            Assert.AreEqual(0, borrower.BorrowedBooks.Count);
        }

        [TestMethod]
        public void ViewBooks_ShouldReturnAllBooks()
        {
            library.AddBook(new Book());
            Assert.AreEqual(1, library.ViewBooks().Count);
        }

        [TestMethod]
        public void ViewBorrowers_ShouldReturnAllBorrowers()
        {
            library.RegisterBorrower(new Borrower());
            Assert.AreEqual(1, library.ViewBorrowers().Count);
        }
    }
}
